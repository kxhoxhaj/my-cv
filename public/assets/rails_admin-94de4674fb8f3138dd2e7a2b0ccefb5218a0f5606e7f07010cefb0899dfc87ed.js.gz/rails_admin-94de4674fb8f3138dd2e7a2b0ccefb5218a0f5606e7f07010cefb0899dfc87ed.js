import "rails_admin/src/rails_admin/base";
